# DocBrain Starter Installer
# Requires Administrator privileges

param(
    [string]$InstallDir = "$env:ProgramFiles\DocBrain"
)

Write-Host "DocBrain Starter Installer" -ForegroundColor Green
Write-Host "=========================" -ForegroundColor Green

# Check if running as Administrator
$isAdmin = ([Security.Principal.WindowsPrincipal] [Security.Principal.WindowsIdentity]::GetCurrent()).IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)
if (-not $isAdmin) {
    Write-Host "Please run this script as Administrator" -ForegroundColor Red
    exit 1
}

# Create installation directory
if (!(Test-Path $InstallDir)) {
    New-Item -ItemType Directory -Path $InstallDir | Out-Null
}

# Copy files
Write-Host "Copying files to $InstallDir..." -ForegroundColor Yellow
Copy-Item -Path "$PSScriptRoot\.." -Destination $InstallDir -Recurse -Force

# Set environment variables
$env:POSTGRES_PASSWORD = "docbrain123"
$env:MINIO_ROOT_USER = "minioadmin"
$env:MINIO_ROOT_PASSWORD = "minioadmin123"
$env:BASIC_AUTH_HASH = '$2a$10$nw6OCgmuORiO6KlokWLnnO6KlokWLnnO6KlokWLnnO6KlokWLnnO6'

# Create .env file
$envContent = @"
POSTGRES_PASSWORD=docbrain123
MINIO_ROOT_USER=minioadmin
MINIO_ROOT_PASSWORD=minioadmin123
BASIC_AUTH_HASH=`$2a`$10`$nw6OCgmuORiO6KlokWLnnO6KlokWLnnO6KlokWLnnO6KlokWLnnO6
"@
$envContent | Out-File -FilePath "$InstallDir\config\.env" -Encoding UTF8

# Create documents directories
New-Item -ItemType Directory -Path "$InstallDir\docker\documents" -Force | Out-Null
New-Item -ItemType Directory -Path "$InstallDir\docker\processed" -Force | Out-Null
New-Item -ItemType Directory -Path "$InstallDir\docker\blob-storage" -Force | Out-Null

# Run hardware check to select appropriate models
Write-Host "Detecting system hardware..." -ForegroundColor Yellow
Set-Location "$InstallDir\installer"
python hardware_check.py

Write-Host "Starting DocBrain services..." -ForegroundColor Yellow
Set-Location "$InstallDir\docker"
docker-compose up -d

Write-Host "Installation complete!" -ForegroundColor Green
Write-Host "Access DocBrain at: https://localhost" -ForegroundColor Cyan
Write-Host "Username: docbrain" -ForegroundColor Cyan
Write-Host "Password: docbrain" -ForegroundColor Cyan
