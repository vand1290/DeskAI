import psutil
import json
import os
import torch

def get_system_info():
    """Get detailed system information"""
    ram_gb = psutil.virtual_memory().total / (1024**3)
    disk_gb = psutil.disk_usage('/').free / (1024**3)
    
    gpu_available = torch.cuda.is_available()
    gpu_memory_gb = 0
    if gpu_available:
        gpu_memory_gb = torch.cuda.get_device_properties(0).total_memory / (1024**3)
    
    return {
        "ram_gb": ram_gb,
        "disk_gb": disk_gb,
        "gpu_available": gpu_available,
        "gpu_memory_gb": gpu_memory_gb
    }

def select_models(system_info):
    """Select appropriate models based on system resources"""
    ram_gb = system_info["ram_gb"]
    disk_gb = system_info["disk_gb"]
    gpu_available = system_info["gpu_available"]
    gpu_memory_gb = system_info["gpu_memory_gb"]
    
    # Determine tier based on resources
    if gpu_memory_gb >= 8 or (ram_gb >= 16 and disk_gb >= 30):
        tier = "A"  # High-end
    elif gpu_memory_gb >= 4 or (ram_gb >= 12 and disk_gb >= 25):
        tier = "B"  # Mid-high
    elif gpu_memory_gb >= 2 or (ram_gb >= 8 and disk_gb >= 20):
        tier = "C"  # Mid-range
    else:
        tier = "D"  # Low-end
    
    # Model recommendations based on tier
    model_recommendations = {
        "A": ["qwen2:7b", "mistral:7b", "llama3:8b"],
        "B": ["mistral:7b", "phi3:mini", "qwen2:7b"],
        "C": ["phi3:mini", "mistral:7b", "tinyllama:1.1b"],
        "D": ["tinyllama:1.1b", "phi3:mini", "stablelm2:1.6b"]
    }
    
    return {
        "tier": tier,
        "models": model_recommendations.get(tier, model_recommendations["D"])
    }

def main():
    print("DocBrain Hardware Detection")
    print("===========================")
    
    system_info = get_system_info()
    print(f"RAM: {system_info['ram_gb']:.2f} GB")
    print(f"Disk Space: {system_info['disk_gb']:.2f} GB")
    print(f"GPU Available: {system_info['gpu_available']}")
    if system_info['gpu_available']:
        print(f"GPU Memory: {system_info['gpu_memory_gb']:.2f} GB")
    
    model_selection = select_models(system_info)
    print(f"\nHardware Tier: {model_selection['tier']}")
    print("Recommended Models:")
    for model in model_selection['models']:
        print(f"  - {model}")
    
    # Save model selection to config
    config_path = os.path.join(os.path.dirname(__file__), "..", "config", "models.json")
    with open(config_path, 'w') as f:
        json.dump({"models": model_selection['models']}, f, indent=2)
    
    print(f"\nModel configuration saved to {config_path}")

if __name__ == "__main__":
    main()
